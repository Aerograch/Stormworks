Library for aiding lua development in Stormworks
