pi=math.pi
pi2=pi*2
sin = math.sin
cos = math.cos
acos = math.acos
asin = math.asin
atan = math.atan
tan = math.tan

function sgn(x)
	return x<0 and -1 or 1
end

function clamp(x,l,u)
	return math.min(math.max(x,l),u)
end

function len(x,y)
	return math.sqrt(x^2+y^2)
end

function norm(x)
	return x%pi2
end

function norm2(x)
	return (x-pi)%pi2-pi
end