-- Vector:

function vector(x,y,z)return{
x or 0,y or 0,z or 0,
magnitude=function (a)local m=a[1]^2+a[2]^2+a[3]^2 return m==1 and 1 or math.sqrt(m)end,
dot=function (a,b)return type(b)=="table"and a[1]*b[1]+a[2]*b[2]+a[3]*b[3]or vector(a[1]*b,a[2]*b,a[3]*b)end,
cross=function (a,b)return vector(a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1])end,
add=function (a,b)return vector(a[1]+b[1],a[2]+b[2],a[3]+b[3])end,
subtract=function (a,b)return vector(a[1]-b[1],a[2]-b[2],a[3]-b[3])end,
normalize=function (a)return a:dot(1/a:magnitude())end,
localToGlobal=function (a,bm)return bm[1]:dot(a[1]):add(bm[2]:dot(a[2])):add(bm[3]:dot(a[3]))end,
globalToLocal=function (a,bm)return vector(a:dot(bm[1]),a:dot(bm[2]),a:dot(bm[3]))end,
axang=function (a,ax)
local bi,bj=a:cross(ax):normalize(),ax:normalize()
local bk=bj:cross(bi)
bi,bk=vector(math.cos(ax:magnitude()),0,-math.sin(ax:magnitude())):localToGlobal({bi,bj,bk}),vector(math.sin(ax:magnitude()),0,math.cos(ax:magnitude())):localToGlobal(
{bi,bj,bk})
return ax:magnitude()~=0 and vector(0,ax:normalize():dot(a),ax:normalize():cross(a):magnitude()):localToGlobal({bi,bj,bk}) or a
end,
disp=function (a,headtohud,hudnormalize,fact)
local t=a:dot(hudnormalize:dot(headtohud)/hudnormalize:dot(a)):subtract(headtohud)
return t[1]*fact,-t[2]*fact
end,
dsimp=function (a,fact)
return a[1]/a[3]*fact,-a[2]/a[3]*fact
end,
}end

-- Basis:

function ijkb(x,y,z,t)
local sx,cx,sy,cy,sz,cz=math.sin(x),math.cos(x),math.sin(y),math.cos(y),math.sin(z),math.cos(z)
return t~="aer"and{vector(cy*cz,cy*sz,-sy),vector(sx*sy*cz-cx*sz,sx*sy*sz+cx*cz,sx*cy),vector(cx*sy*cz+sx*sz,cx*sy*sz-sx*cz,cx*cy)}or{vector(cz*cx+sz*sy*sx,-sz*cy,sz*sy*cx-cz*sx),vector(sz*cx-cz*sy*sx,cz*cy,-cz*sy*cx-sz*sx),vector(sx*cy,sy,cx*cy)}
end
function ijk(...)return table.unpack(ijkb(...))end

function fullaxang(bm,a)return{bm[1]:axang(a),bm[2]:axang(a),bm[3]:axang(a)}end

function fulllocalToGlobal(b1,b2)
return {b1[1]:localToGlobal(b2),b1[2]:localToGlobal(b2),b1[3]:localToGlobal(b2)}
end

function fullglobalToLocal(b1,b2)
return {b1[1]:globalToLocal(b2),b1[2]:globalToLocal(b2),b1[3]:globalToLocal(b2)}
end

function getVector(si)
	s=property.getText(si)
	local pi,t=1,{}
	for i=1,s:len() do
		if s:sub(i,i)=="," then
			t[#t+1]=tonumber(s:sub(pi,i-1))
			pi=i+1
		elseif i==s:len() then
			t[#t+1]=tonumber(s:sub(pi,-1))
		end
	end
	return vector(table.unpack(t))
end